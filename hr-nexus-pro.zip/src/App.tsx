/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';

// Simple placeholder for other pages
const LoginPage = () => <div className="flex items-center justify-center h-screen"><h1 className="text-3xl">Login Page</h1></div>;
const PlanningPage = () => <div className="flex items-center justify-center h-screen"><h1 className="text-3xl">Planning Page</h1></div>;

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/planning" element={<PlanningPage />} />
        {/* Add other routes here */}
      </Routes>
    </Router>
  );
}
