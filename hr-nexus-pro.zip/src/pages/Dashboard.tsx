import { useState, useEffect } from 'react';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

// --- Chart Data Interfaces ---
type ChartData = {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
    fill?: boolean;
    tension?: number;
  }[];
};

// --- Initial Empty State for Charts ---
const initialChartData: ChartData = {
  labels: [],
  datasets: [{
    label: '',
    data: [],
    backgroundColor: 'rgba(54, 162, 235, 0.6)',
    borderColor: 'rgba(54, 162, 235, 1)',
    borderWidth: 1,
  }],
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
    },
    title: {
      display: true,
      font: {
        size: 16,
        family: 'Inter, sans-serif',
      }
    },
  },
  scales: {
    y: {
        beginAtZero: true
    }
  }
};

const SkeletonLoader = () => (
  <div className="h-80 bg-slate-200 rounded-lg animate-pulse"></div>
);

export default function Dashboard() {
  const [employeeData, setEmployeeData] = useState<ChartData>(initialChartData);
  const [absenteeismData, setAbsenteeismData] = useState<ChartData>(initialChartData);
  const [turnoverData, setTurnoverData] = useState<ChartData>(initialChartData);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // NOTE: In a real app, the token would come from a state management solution (Context, Redux, etc.)
        // after the user logs in. For now, we'll use a placeholder.
        const token = localStorage.getItem('authToken'); // This will be null for now.

        const response = await fetch('/api/dashboard/stats', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.status === 401) {
            // For demonstration, we'll proceed without auth, but in real life this is a hard stop.
            // throw new Error('Non autorisé. Veuillez vous connecter.');
            console.warn('Bypassing auth for demonstration purposes.');
        }

        if (!response.ok && response.status !== 401) {
          throw new Error('Erreur lors de la récupération des données');
        }
        
        // A real app would handle the 401 properly. Here we just try to get the json.
        const data = await response.json();

        // Format data for charts
        setEmployeeData({
          labels: data.employeeByFiliale.labels,
          datasets: [{
            label: 'Nombre d\'employés',
            data: data.employeeByFiliale.data,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
          }]
        });

        setAbsenteeismData({
            labels: ['Présent', 'Absent'],
            datasets: [{
                label: 'Taux d\'absentéisme',
                data: [data.absenteeism.present, data.absenteeism.absent],
                backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 99, 132, 0.6)'],
            }]
        });

        setTurnoverData({
            labels: data.turnover.labels,
            datasets: [{
                label: 'Événements de turnover',
                data: data.turnover.data,
                borderColor: 'rgb(255, 99, 132)',
                tension: 0.1,
                fill: false
            }]
        });

      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-800">
      <div className="container mx-auto p-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-8">Dashboard RH Global</h1>
        
        {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative mb-6" role="alert">
            <strong className="font-bold">Erreur:</strong>
            <span className="block sm:inline"> {error}</span>
        </div>}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow-md col-span-1 lg:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Effectif par Filiale</h2>
            {loading ? <SkeletonLoader /> : <div className="h-80"><Bar options={{...chartOptions, plugins: {...chartOptions.plugins, title: {...chartOptions.plugins.title, text: 'Nombre d\'employés actifs'}}}} data={employeeData} /></div>}
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">Taux d'Absentéisme (Mensuel)</h2>
            {loading ? <SkeletonLoader /> : <div className="h-80 flex items-center justify-center"><Doughnut options={{...chartOptions, maintainAspectRatio: true, plugins: {...chartOptions.plugins, title: {...chartOptions.plugins.title, text: 'Absentéisme ce mois-ci (%)'}}}} data={absenteeismData} /></div>}
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-md col-span-1 lg:col-span-3">
            <h2 className="text-xl font-semibold mb-4">Évolution du Turnover</h2>
            {loading ? <SkeletonLoader /> : <div className="h-80"><Line options={{...chartOptions, plugins: {...chartOptions.plugins, title: {...chartOptions.plugins.title, text: 'Taux de rotation sur 6 mois'}}}} data={turnoverData} /></div>}
          </div>
        </div>
      </div>
    </div>
  );
}
