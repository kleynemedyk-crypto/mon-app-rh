import { Router } from 'express';
import prisma from '../lib/prisma';
import { AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/planning/weekly
// Retrieves the weekly schedule for employees.
router.get('/weekly', async (req: AuthRequest, res) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Not authenticated' });
  }

  const { role, filialeId } = req.user;

  // Define a base where clause for data isolation
  const whereClause: { filialeId?: string } = {};
  if (role === 'MANAGER' && filialeId) {
    whereClause.filialeId = filialeId;
  }

  try {
    // For now, we'll return a list of employees and their basic info.
    // A real implementation would involve a more complex model for schedules.
    const employees = await prisma.employee.findMany({
      where: whereClause,
      select: {
        id: true,
        firstName: true,
        lastName: true,
        campaign: true,
        filiale: {
          select: {
            name: true,
          },
        },
      },
      orderBy: {
        lastName: 'asc',
      }
    });

    // Mocking weekly schedule data for each employee
    const scheduleData = employees.map(emp => ({
      ...emp,
      filialeName: emp.filiale.name,
      schedule: {
        lundi: '09:00 - 17:00',
        mardi: '09:00 - 17:00',
        mercredi: '09:00 - 17:00',
        jeudi: '09:00 - 17:00',
        vendredi: '09:00 - 17:00',
        samedi: 'Repos',
        dimanche: 'Repos',
      }
    }));

    res.status(200).json(scheduleData);

  } catch (error) {
    console.error('Failed to fetch weekly planning:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
