import { Router } from 'express';
import prisma from '../lib/prisma';
import { AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/dashboard/stats
// Retrieves key performance indicators for the HR dashboard.
router.get('/stats', async (req: AuthRequest, res) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Not authenticated' });
  }

  const { role, filialeId } = req.user;

  try {
    // Define a base where clause for data isolation
    const whereClause: { filialeId?: string } = {};
    if (role === 'MANAGER' && filialeId) {
      whereClause.filialeId = filialeId;
    }

    // 1. Employee count by filiale
    const employeeByFiliale = await prisma.employee.groupBy({
      by: ['filialeId'],
      _count: {
        id: true,
      },
      where: role === 'MANAGER' ? { filialeId } : {},
    });

    // Fetch filiale names for labels
    const filiales = await prisma.filiale.findMany({
        where: {
            id: { in: employeeByFiliale.map(f => f.filialeId) }
        }
    });
    const filialeMap = new Map(filiales.map(f => [f.id, f.name]));

    const employeeByFilialeData = {
        labels: employeeByFiliale.map(f => filialeMap.get(f.filialeId) || 'Unknown'),
        data: employeeByFiliale.map(f => f._count.id)
    }

    // 2. Absenteeism rate (simplified for now)
    const attendanceStats = await prisma.attendance.aggregate({
        _sum: {
            scheduledHours: true,
            workedHours: true,
        },
        where: whereClause
    });

    const totalScheduled = attendanceStats._sum.scheduledHours || 0;
    const totalWorked = attendanceStats._sum.workedHours || 0;
    const absenteeismRate = totalScheduled > 0 ? ((totalScheduled - totalWorked) / totalScheduled) * 100 : 0;
    const absenteeismData = {
        present: 100 - absenteeismRate,
        absent: absenteeismRate
    }

    // 3. Turnover rate (highly simplified: new contracts vs ended contracts in last 6 months)
    // This is a placeholder logic. Real turnover is more complex.
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const newHires = await prisma.contract.count({
        where: {
            ...whereClause,
            startDate: { gte: sixMonthsAgo }
        }
    });

    const terminations = await prisma.contract.count({
        where: {
            ...whereClause,
            endDate: { gte: sixMonthsAgo }
        }
    });
    
    // Simplified turnover data for the chart
    const turnoverData = {
        labels: ['Jan', 'Fev', 'Mar', 'Avr', 'Mai', 'Juin'], // Placeholder labels
        data: [2, 3, 1, 4, 2, 3] // Placeholder data representing turnover events
    }

    res.status(200).json({
      employeeByFiliale: employeeByFilialeData,
      absenteeism: absenteeismData,
      turnover: turnoverData
    });

  } catch (error) {
    console.error('Failed to fetch dashboard stats:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
