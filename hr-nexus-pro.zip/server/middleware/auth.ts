import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import prisma from '../lib/prisma';

// Extend the Express Request interface to include the user object
export interface AuthRequest extends Request {
  user?: {
    id: string;
    role: string;
    filialeId?: string;
  };
}

export const protect = (req: AuthRequest, res: Response, next: NextFunction) => {
  const bearer = req.headers.authorization;

  if (!bearer || !bearer.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Unauthorized: No token provided' });
  }

  const [, token] = bearer.split(' ');

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized: Invalid token format' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as { id: string };
    
    prisma.user.findUnique({
      where: { id: decoded.id },
      include: { employee: true }
    }).then(user => {
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized: User not found' });
      }
      
      req.user = {
        id: user.id,
        role: user.role,
        filialeId: user.employee?.filialeId
      };
      next();
    });

  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ message: 'Unauthorized: Invalid token' });
  }
};
